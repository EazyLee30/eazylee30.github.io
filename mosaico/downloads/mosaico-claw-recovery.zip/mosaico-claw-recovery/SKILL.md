---
name: mosaico-claw-recovery
description: 恢复 ESP-Mosaico 官方 Claw，将它保存为 Vibe Mode 本地 Idea，并验证与已有固件的离线切换。适用于恢复官方界面、缺少 Claw 安装码、刷入第三方固件后无法切回等任务；不负责把第三方固件改成 Claw 首页原生 App。
---

# Mosaico 官方固件与 Ideas 切换

目标是恢复官方界面，同时在设备 NAND 中留下能离线打开的 Claw 副本。恢复运行固件和保存本地 Idea 是两步，不能把前者当成后者已经完成。

## 先确定用户要什么

- Works 内容、Claw 首页原生 App、Vibe Mode 固件切换是不同开发方式。这个流程实现第三种；原生图标需要相应固件源码集成。
- Vibe Mode 是设备上的维护固件，ROM Download Mode 是芯片下载模式。需要 Vibe Mode 时使用 AI + Power；BOOT + Power 是 ROM 下载方式。黑屏不等于 Vibe Mode 已启动。
- 有可用 Vibe Mode 时优先通过其接口恢复。不要为了添加一个 Idea 擦除整片 Flash、NAND、NVS、身份或凭据。

## 检查并准备

1. 读取当前工作区和工具仓库的 AGENTS.md。设备操作使用消费工作区的 `mosaico.py`，复用已有 Gateway；不要同时让多个进程抢占串口。
2. 读取 live device-status、芯片、Flash 容量、Vibe Mode 版本、布局以及现有 Ideas 清单。重新发现端口和 Device ID，不能沿用旧会话的标识或路径。
3. 从官方来源核实目标镜像及对应源码。随附脚本只接受已验证的 Claw 0.5.0 完整镜像；不认识的哈希或布局必须先调查，不能改常量强行通过。
4. 需要本地保存或遇到旧版 UI/API 问题时，阅读 [Vibe 0.2.0 实施细节](references/vibe-020.md)。这是已验证版本的流程，不是所有后续版本的保证。

## 离线准备包

```sh
python3 scripts/prepare_claw_050.py \
  --image /path/to/ESP-Mosaico-Claw_v0.5.0.bin \
  --output /path/to/new-output-directory
```

脚本检查完整镜像 SHA-256、芯片、布局、应用校验和及附加 SHA，生成本地 Idea 目录、逐文件哈希和给官方 bundle builder 使用的 manifest。它不连接设备、不刷机。输出包含官方资源的副本，不要把生成的固件当作自己的作品发布。

需要 `.irisfw` 时增加 `--iris-tools /path/to/ESP-Iris/components/esp_iris/tools`，调用已检查的官方 `build_system_update_bundle`。生成的是本地重打包文件，不能称为官方发布的签名包。

## 写入与保存

- 若尚未恢复 Claw，使用 `mosaico.py iris system-update`，明确选定当前设备和包。维护分区、bootloader、设备凭据不在这次包的写入范围。
- 刷写后丢失 Iris 连接不能直接判为失败。Claw 0.5.0 可能没有 Iris 健康确认端点；检查已提交的写入证据、USB 产品和屏幕。`outcome_unknown` 时先核对原操作，不能盲目重刷。
- 在 Vibe Mode 中，通过官方文件 API 保存新的 `ideas/dxxxxx` 目录。先列出现有目录，检查短码冲突和剩余空间；上传默认禁止覆盖。写入 payload、manifest 后最后提交 `.roots`，防止半包成为可见条目。
- 需要工作区适配器时，作为 `mosaico.py` 子命令使用官方 Gateway API；限制为这个新目录，不提供任意覆盖、删除或格式化功能。
- 每个上传操作须完成且大小、SHA-256 与本地记录匹配。超时后先查询原操作和目标文件，禁止直接重放。

## 完成标准

1. 原有 Ideas 仍在；新条目显示 `ESP-Claw` 和正确版本。
2. 从这个已保存的条目执行 Open，让设备完成包校验及启动流程。
3. 记录实际观察到的证据：NAND 包提交、设备校验进度、USB 产品、屏幕或健康事件。没有做完整第三方→Claw 往返时，不得声称测过。
4. 告诉用户以后用 AI + Power 进入 Vibe Mode，选择 Idea 切换；一次运行一个主固件，切换可能重新写入 NOR，不是并行运行多个 App。
5. 结束本次创建的 Gateway 保活客户端，保留恢复文件和验证记录。仅写教程或制作 skill 时，不因这个流程而再次操作硬件。
