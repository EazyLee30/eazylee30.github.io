#!/usr/bin/env python3
"""Offline-only packaging of the known official Claw 0.5.0 image. No device IO."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

IMAGE_SHA = 'bd45c135034d50cd9d0d36cfbe5219c2e760274d27d87a0087ec4bc38206b10e'
LAYOUT = {'main_app': (0x210000, 0x7d0000), 'ui_apps': (0x9e0000, 0x320000),
          'system': (0xd00000, 0x2ee000)}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()


def application_image(data):
    if len(data) < 24 or data[0] != 0xe9 or struct.unpack_from('<H', data, 12)[0] != 32:
        raise ValueError('Expected an ESP32-S31 application image')
    if data[23] != 1 or not 1 <= data[1] <= 16:
        raise ValueError('Unsupported image header')
    position, checksum = 24, 0xef
    for _ in range(data[1]):
        if position + 8 > len(data):
            raise ValueError('Truncated segment header')
        length = struct.unpack_from('<I', data, position + 4)[0]
        position += 8
        if position + length > len(data):
            raise ValueError('Truncated segment payload')
        for byte in data[position:position + length]:
            checksum ^= byte
        position += length
    end = (position + 16) // 16 * 16
    if end + 32 > len(data) or data[end - 1] != checksum:
        raise ValueError('Application checksum mismatch')
    if hashlib.sha256(data[:end]).digest() != data[end:end + 32]:
        raise ValueError('Application appended SHA-256 mismatch')
    return data[:end + 32]


def prepare(image, output, iris_tools=None):
    data = image.read_bytes()
    if len(data) != 16703488 or digest(data) != IMAGE_SHA:
        raise ValueError('Not the verified official Claw 0.5.0 image; no output written')
    if output.exists():
        raise ValueError('Output already exists; choose a new directory')
    parts = {}
    for offset in range(0x8000, 0x8c00, 32):
        row = data[offset:offset + 32]
        if row[:2] != b'\xaa\x50':
            break
        _, _, _, start, size, raw_name, _ = struct.unpack('<HBBII16sI', row)
        parts[raw_name.split(b'\0')[0].decode()] = (start, size)
    if any(parts.get(name) != region for name, region in LAYOUT.items()):
        raise ValueError('Unexpected partition layout')
    components, payloads = [], {}
    for index, (name, kind) in enumerate([
            ('partition_table', 'partition_table'), ('main_app', 'application'),
            ('ui_apps', 'data'), ('system', 'data')], 1):
        offset, size = (0x8000, 4096) if name == 'partition_table' else parts[name]
        chunk = data[offset:offset + size]
        if len(chunk) != size:
            raise ValueError('Truncated partition: ' + name)
        if kind == 'application':
            chunk = application_image(chunk)
        filename = name + '.bin'
        payloads[filename] = chunk
        components.append({'id': index, 'kind': kind, 'target_offset': offset,
                           'file': filename, 'size': len(chunk), 'sha256': digest(chunk)})
    release_id = digest(''.join(c['sha256'] for c in components).encode())
    code, app_id = 'd' + release_id[:5], 'development-edge_agent'
    manifest = {'schema': 'esp-iris-system-update/0.2', 'release': '0.5.0',
                'minimum_recovery_version': '0.2.0',
                'target': {'chip_id': 32, 'flash_size': 16777216},
                'components': components, 'target_layout_sha256': components[0]['sha256']}
    inner = encode(manifest)
    descriptor = {'schema': 'mosaico-ideas/local/2', 'release_id': release_id,
                  'application': {'code': code, 'id': app_id, 'name': 'ESP-Claw',
                                  'description': 'Official ESP-Mosaico Claw 0.5.0. Saved locally for offline switching.'},
                  'firmware': {'manifest': {'path': 'firmware/manifest.json',
                                            'size': len(inner), 'sha256': digest(inner)}},
                  'device': {'profile': 'esp-mosaico/v2', 'default_locale': 'en',
                             'presentations': []}}
    root = encode(descriptor)
    journal = struct.pack('<I65s3xI65s3xI65s3x', 0x49444531, app_id.encode(),
                          len(root), digest(root).encode(), 0, b'')
    files = {'current/firmware/' + name: chunk for name, chunk in payloads.items()}
    files.update({'current/firmware/manifest.json': inner,
                  'current/manifest.json': root, '.roots': journal})
    output.mkdir(parents=True)
    for name, chunk in files.items():
        target = output / 'idea' / code / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(chunk)
    source = {'schema': manifest['schema'], 'release': 'mosaico-claw-0.5.0',
              'minimum_recovery_version': '0.2.0', 'target': manifest['target'],
              'components': [{k: c[k] for k in ('id', 'kind', 'target_offset', 'file')}
                             for c in components]}
    (output / 'source-manifest.json').write_bytes(encode(source))
    report = {'source_sha256': IMAGE_SHA, 'code': code, 'release_id': release_id,
              'files': {name: {'size': len(chunk), 'sha256': digest(chunk)}
                        for name, chunk in files.items()}}
    (output / 'package-info.json').write_text(json.dumps(report, indent=2) + '\n')
    if iris_tools:
        sys.path.insert(0, str(iris_tools.resolve()))
        from iris_gateway.system_update import build_system_update_bundle
        build_system_update_bundle(output / 'ESP-Mosaico-Claw_v0.5.0.irisfw', source,
                                   output / 'idea' / code / 'current/firmware')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--iris-tools', type=Path)
    args = parser.parse_args()
    try:
        report = prepare(args.image, args.output, args.iris_tools)
    except (ValueError, OSError, ImportError) as error:
        parser.exit(1, str(error) + '\n')
    print(json.dumps({'output': str(args.output.resolve()), 'code': report['code'],
                      'files': len(report['files']), 'device_operations': 0}))


if __name__ == '__main__':
    main()
