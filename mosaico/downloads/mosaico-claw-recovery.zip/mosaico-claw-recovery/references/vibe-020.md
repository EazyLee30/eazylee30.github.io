# Vibe Mode 0.2.0 / Claw 0.5.0 已验证流程

实机日期：2026-10-23。适用条件：ESP32-S31、16 MiB NOR、ESP-Mosaico v2、Recovery ABI 2、layout version 5。已检查的工具源码提交为 `be151ae047014e79a9c7ae0092dd203844499003`。更新版本必须重新核对。

## 官方来源与关键源码

- [官方固件页](https://mosaico.espressif.com/firmware-update/)
- [Claw 0.5.0 完整镜像](https://mosaico.espressif.com/firmware/ESP-Mosaico-Claw_v0.5.0.bin)
- [开发固件捕获及 local/2 descriptor](https://github.com/esp-mosaico/esp-mosaico-utils/blob/be151ae047014e79a9c7ae0092dd203844499003/esp-mosaico-vibe-mode/firmware/vibe-mode/components/app_ideas/src/ideas_development.c)
- [NAND 目录和 journal](https://github.com/esp-mosaico/esp-mosaico-utils/blob/be151ae047014e79a9c7ae0092dd203844499003/esp-mosaico-vibe-mode/firmware/vibe-mode/components/app_ideas/src/ideas_store.c)
- [包解析规则](https://github.com/esp-mosaico/esp-mosaico-utils/blob/be151ae047014e79a9c7ae0092dd203844499003/esp-mosaico-vibe-mode/firmware/vibe-mode/components/app_ideas/src/ideas_package.c)
- [公开文件 HTTP API](https://github.com/esp-mosaico/esp-mosaico-utils/blob/be151ae047014e79a9c7ae0092dd203844499003/ESP-Iris/components/esp_iris/tools/iris_gateway/file_routes.py)

这是源码分析和公开接口操作，不需要 REA。只有源码无法解释实际产物时，才考虑用户授权范围内的逆向工作。

## 存储模型与写入范围

Vibe Mode 留在维护分区；一个主应用在 NOR 中运行。NAND 存放多个 Idea 的安装材料。打开另一个 Idea 时，设备验证保存的包，并按需要写入 NOR 后重启。保存副本不会自动产生 Claw 首页原生 App。

| 文件 | 偏移 | 字节数 |
|---|---:|---:|
| partition_table.bin | 0x8000 | 4096 |
| main_app.bin | 0x210000 | 6586784 |
| ui_apps.bin | 0x9e0000 | 3276800 |
| system.bin | 0xd00000 | 3072000 |

不要把 bootloader、vibe_mode、otadata、sysmeta、NVS、coredump 加进普通 Idea。保存的是经验证的原始组件，不是重编译的程序。

## 本地 Idea 格式

```text
/nand/ideas/dxxxxx/
  .roots
  current/
    manifest.json
    firmware/
      manifest.json
      partition_table.bin
      main_app.bin
      ui_apps.bin
      system.bin
```

外层 schema 为 `mosaico-ideas/local/2`，包含 application 的 code/id/name/description、内层 manifest 的 path/size/sha256，以及 `esp-mosaico/v2` device profile。内层为 `esp-iris-system-update/0.2`，包含各组件偏移、大小和 SHA-256。local/2 的 presentations 必须为空，使用默认图标；不要捏造云端六位数字安装码。

release_id 是各组件 SHA-256 十六进制字符串依次拼接后再次取 SHA-256。短码取 `d` 加 release_id 前五位；若已有同名目录，先比较其身份，不能覆盖不相干副本。本脚本不会替你处理设备上的短码碰撞。

这个版本的 `.roots` 是 216 字节 C ABI 记录，对应 Python `<I65s3xI65s3xI65s3x`：magic `0x49444531`、application_id、两个 root 的 size 与 64 字符 SHA。未使用的第二个 root 清零。实机既有记录已验证该布局。它是本地完整性 journal，不是官方签名。

## 文件接口

从当前项目的 Gateway 获取 URL 和当前 Device ID，不要写死端口。路由：

- `GET /v2/devices/{id}/files/volumes`
- `GET /v2/devices/{id}/files?volume=nand&path=ideas`
- `GET /v2/devices/{id}/file?volume=nand&path=...`
- `POST /v2/devices/{id}/directories`，JSON 为 `{ "volume": "nand", "path": "ideas/dxxxxx" }`
- `PUT /v2/devices/{id}/file?volume=nand&path=...`，二进制 body、Content-Length，默认禁止覆盖。

通过工作区 `mosaico.py` 适配器调用，保留 operation ID、结果和校验记录。不要将整个 NAND、凭据、设备 ID、串口日志直接发布到文章或 skill。

## 两个已遇到的版本问题

1. **Develop 页面没有保存按钮**：后端仍有捕获逻辑，但本机 Vibe 0.2.0 UI 已移除入口。本次使用文件接口保存经过校验的 local/2 包。
2. **上传超过 1 MiB 失败**：该工具提交的 `gateway.py` resource middleware 只把 `/files/` 识别为大请求，而上传地址结尾是 `/file`。报错为 `Maximum request body size 1048576 exceeded`。仅在确认同样问题时，将 `/file` 纳入大请求分类，沿用既有 upload_bytes 和文件路由大小限制。安全停止空闲 Gateway，再重启加载修改；不能中断正在提交的设备写入。实际 6.6 MB 上传成功验证了修复。

## 刷新与启动证据

文件写完后，Ideas 列表可能缓存旧结果。正常重新进入 Vibe Mode 可重新扫描。需要保持连接时，本版本切换一次显示语言再恢复原语言，会触发 `IDEAS_RELOCALIZE` 扫描；这只是源码确认过的临时刷新办法。

不要假定 raw RPC `0x7fff/2` 在 Vibe Mode 自身可用。本机返回 `0x105`；普通 restart 也可能启动主应用。先查当前固件服务与 next boot 信息。

本次证据：七个新文件提交成功，大小和 SHA 一致；原有两个 Idea 保留；列表出现 ESP-Claw 0.5.0；从该条目 Open，设备显示本地写入进度，重启后 USB 产品为 ESP-Mosaico-Claw。此前官方界面已由用户确认。没有测试所有第三方应用的往返组合。
